#
# Copyright (c) 2021 Cisco Systems, Inc and its affiliates
# All rights reserved
#
from msxswagger.msxswagger import MSXSwaggerConfig, DocumentationConfig, MSXSwaggerDefaultConfig, Security, Sso, AppInfo